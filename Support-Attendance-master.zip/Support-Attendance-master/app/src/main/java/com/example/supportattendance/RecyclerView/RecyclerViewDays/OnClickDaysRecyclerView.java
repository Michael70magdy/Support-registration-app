package com.example.supportattendance.RecyclerView.RecyclerViewDays;

public interface OnClickDaysRecyclerView {
    void onclick(int position);
}
