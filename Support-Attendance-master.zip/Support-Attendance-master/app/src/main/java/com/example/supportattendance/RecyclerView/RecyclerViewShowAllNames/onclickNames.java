package com.example.supportattendance.RecyclerView.RecyclerViewShowAllNames;

public interface onclickNames {
    void onclick(int position,String s);
}
