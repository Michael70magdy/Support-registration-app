package com.example.supportattendance.RecyclerView.Attendance;

public interface OnClickNamesRecyclerView {
    void onclick(int position,Boolean attendee,Boolean Task);
}
